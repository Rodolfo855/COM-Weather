//
//  COM_WeatherApp.swift
//  COM Weather
//
//  Created by Victor Rosales  on 2/12/26.
//

import SwiftUI

@main
struct COM_WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
